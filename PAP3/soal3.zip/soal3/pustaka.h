#ifndef PUSTAKA_H_INCLUDED
#define PUSTAKA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void swap(int *a,int *b);
void cetak(int array[],int jml_data);
void bubble_sort1(int array[], int jml_data);

#endif // PUSTAKA_H_INCLUDED
