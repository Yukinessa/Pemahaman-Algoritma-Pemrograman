/*
NAMA = KUN AMRIN AMANU
NIM = A11.2017.10333
*/
#include "pustaka.h"

int main()
{
    int array[]={3,44,38,5,47};
    bubble_sort1(array,5);
    return 0;
}
